import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/reset': 'http://localhost:7860',
      '/step': 'http://localhost:7860',
      '/evaluate': 'http://localhost:7860',
      '/state': 'http://localhost:7860',
      '/baseline': 'http://localhost:7860',
    }
  }
});
