// Disinformation Analyst — Interactive Web App Logic
document.addEventListener('DOMContentLoaded', () => {
  const selectTask = document.getElementById('select-task');
  const selectScenario = document.getElementById('select-scenario');
  const inputSeed = document.getElementById('input-seed');
  const btnReset = document.getElementById('btn-reset');
  const btnBaseline = document.getElementById('btn-baseline');

  const btnSubmitTag = document.getElementById('btn-submit-tag');
  const btnSubmitTrace = document.getElementById('btn-submit-trace');
  const btnSubmitScore = document.getElementById('btn-submit-score');
  const btnDone = document.getElementById('btn-done');

  let currentObs = null;

  // Tab switching
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tabName = btn.dataset.tab;
      ['nodes', 'edges', 'claims', 'log'].forEach(t => {
        const el = document.getElementById(`tab-${t}-content`);
        if (el) el.style.display = t === tabName ? (t === 'log' ? 'block' : 'grid') : 'none';
      });
    });
  });

  // Logging helper
  function logAction(msg, isError = false) {
    const logEl = document.getElementById('log-entries');
    if (!logEl) return;
    const time = new Date().toLocaleTimeString();
    const color = isError ? '#fca5a5' : '#93c5fd';
    logEl.innerHTML = `<div style="margin-bottom: 0.3rem; color: ${color};">[${time}] ${msg}</div>` + logEl.innerHTML;
  }

  // Reset Environment
  async function resetEnv() {
    const task = selectTask.value;
    const scenario = selectScenario.value;
    const seed = parseInt(inputSeed.value, 10) || 42;

    try {
      const res = await fetch('/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task, scenario, seed })
      });
      if (!res.ok) throw new Error(await res.text());
      currentObs = await res.json();
      logAction(`Environment Reset — Task: ${task}, Scenario: ${scenario}, Seed: ${seed}`);
      renderObservation(currentObs);
      updateEvaluation();
    } catch (err) {
      logAction(`Reset Error: ${err.message}`, true);
    }
  }

  // Execute Step Action
  async function stepAction(actionDict) {
    try {
      const res = await fetch('/step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: actionDict })
      });
      if (!res.ok) throw new Error(await res.text());
      const stepResult = await res.json();
      currentObs = stepResult.observation;
      logAction(`Action: ${JSON.stringify(actionDict)} → Reward: ${stepResult.reward.step_reward.toFixed(2)}, Cumulative: ${stepResult.reward.cumulative.toFixed(3)}`);
      renderObservation(currentObs);
      updateEvaluation();
    } catch (err) {
      logAction(`Step Error: ${err.message}`, true);
    }
  }

  // Update Evaluation Scores
  async function updateEvaluation() {
    try {
      const res = await fetch('/evaluate');
      if (!res.ok) return;
      const evalRes = await res.json();
      
      document.getElementById('score-composite').innerText = evalRes.final_score.toFixed(4);
      document.getElementById('composite-progress').style.width = `${(evalRes.final_score * 100).toFixed(1)}%`;
      document.getElementById('metric-f1').innerText = evalRes.tag_f1.toFixed(2);
      document.getElementById('metric-trace').innerText = evalRes.trace_score.toFixed(2);
      document.getElementById('metric-severity').innerText = evalRes.severity_score.toFixed(2);
    } catch (err) {
      console.error(err);
    }
  }

  // Render Observation Data to UI
  function renderObservation(obs) {
    if (!obs) return;

    // Counts
    document.getElementById('nodes-count').innerText = obs.nodes ? obs.nodes.length : 0;
    document.getElementById('edges-count').innerText = obs.edges ? obs.edges.length : 0;
    document.getElementById('claims-count').innerText = obs.claims ? obs.claims.length : 0;
    document.getElementById('step-taken').innerText = obs.steps_taken || 0;
    document.getElementById('step-rem').innerText = obs.steps_remaining || 50;

    document.getElementById('summary-tagged').innerText = Object.keys(obs.agent_tags || {}).length;
    document.getElementById('summary-traced').innerText = (obs.agent_traces || []).length;
    document.getElementById('summary-scored').innerText = Object.keys(obs.agent_scores || {}).length;

    // Render Nodes
    const nodesContainer = document.getElementById('tab-nodes-content');
    nodesContainer.innerHTML = (obs.nodes || []).map(n => {
      const assignedTag = (obs.agent_tags || {})[n.node_id];
      const tagBadge = assignedTag ? `<span class="node-tag-status tag-${assignedTag}">tagged: ${assignedTag}</span>` : '';
      return `
        <div class="node-card">
          <div class="node-header">
            <span class="node-id">${n.node_id}</span>
            <span class="node-kind kind-${n.kind}">${n.kind}</span>
          </div>
          <div class="node-text">${n.text}</div>
          ${tagBadge}
          <div class="node-meta">
            <span>Src: ${n.source}</span>
            <span>Shares: ${n.share_count}</span>
          </div>
          <div class="node-actions">
            <button class="tag-btn ${assignedTag==='disinformation'?'active':''}" onclick="quickTag('${n.node_id}', 'disinformation')">disinfo</button>
            <button class="tag-btn ${assignedTag==='real'?'active':''}" onclick="quickTag('${n.node_id}', 'real')">real</button>
            <button class="tag-btn ${assignedTag==='satire'?'active':''}" onclick="quickTag('${n.node_id}', 'satire')">satire</button>
            <button class="tag-btn ${assignedTag==='misleading'?'active':''}" onclick="quickTag('${n.node_id}', 'misleading')">misleading</button>
          </div>
        </div>
      `;
    }).join('');

    // Render Edges
    const edgesContainer = document.getElementById('tab-edges-content');
    edgesContainer.innerHTML = (obs.edges || []).map(e => `
      <div class="node-card">
        <div class="node-header">
          <span class="node-id" style="color: #c084fc;">${e.src} → ${e.dst}</span>
          <span class="node-kind" style="background: rgba(99,102,241,0.2); color: #a5b4fc;">${e.relation}</span>
        </div>
        <div style="font-size: 0.8rem; color: var(--text-muted);">Propagation edge in synthetic graph</div>
      </div>
    `).join('');

    // Render Claims
    const claimsContainer = document.getElementById('tab-claims-content');
    claimsContainer.innerHTML = (obs.claims || []).map(c => {
      const scored = (obs.agent_scores || {})[c.claim_id];
      const scoreBadge = scored !== undefined ? `<span class="node-tag-status tag-misleading">severity: ${scored.toFixed(2)}</span>` : '';
      return `
        <div class="node-card">
          <div class="node-header">
            <span class="node-id" style="color: #f472b6;">${c.claim_id}</span>
            ${scoreBadge}
          </div>
          <div class="node-text">${c.text}</div>
          <div style="display: flex; gap: 0.5rem; margin-top: 0.5rem;">
            <input type="range" min="0" max="1" step="0.05" value="${scored !== undefined ? scored : 0.5}" id="range-${c.claim_id}" style="flex: 1;" onchange="quickScore('${c.claim_id}', this.value)">
          </div>
        </div>
      `;
    }).join('');
  }

  // Quick Action Handlers
  window.quickTag = (nodeId, label) => stepAction({ type: 'tag', node_id: nodeId, label });
  window.quickScore = (claimId, val) => stepAction({ type: 'score', claim_id: claimId, severity: parseFloat(val) });

  // Event Listeners
  btnReset.addEventListener('click', resetEnv);

  btnSubmitTag.addEventListener('click', () => {
    const nodeId = document.getElementById('tag-node-id').value.trim();
    const label = document.getElementById('tag-label').value;
    if (nodeId) stepAction({ type: 'tag', node_id: nodeId, label });
  });

  btnSubmitTrace.addEventListener('click', () => {
    const src = document.getElementById('trace-src').value.trim();
    const dst = document.getElementById('trace-dst').value.trim();
    if (src && dst) stepAction({ type: 'trace', src, dst });
  });

  btnSubmitScore.addEventListener('click', () => {
    const claimId = document.getElementById('score-claim-id').value.trim();
    const severity = parseFloat(document.getElementById('score-val').value) || 0.0;
    if (claimId) stepAction({ type: 'score', claim_id: claimId, severity });
  });

  btnDone.addEventListener('click', () => stepAction({ type: 'done' }));

  btnBaseline.addEventListener('click', async () => {
    logAction("Running Dry-Run Baseline Agent across all 3 tasks...");
    try {
      const res = await fetch('/baseline');
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      logAction(`Baseline Finished — Mean Score: ${data.mean_score}`);
      resetEnv();
    } catch (err) {
      logAction(`Baseline Error: ${err.message}`, true);
    }
  });

  // Initial Load
  resetEnv();
});
