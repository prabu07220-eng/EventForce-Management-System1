# 🛡️ Disinformation Analyst — OpenEnv Environment & Studio

A comprehensive, three-task **OpenEnv-compliant evaluation environment** where an LLM agent analyzes synthetic news and social-media propagation graphs to detect, trace, and score disinformation.

This environment simulates real-world **Trust & Safety** workflows performed daily by human analysts at platforms like Twitter/X, Meta, and news verification organizations. It includes a **built-in interactive Web UI Studio** for real-time visualization and manual testing!

---

## 🌟 Key Highlights & Innovations

- **React 18 + Three.js 3D Web Studio:** Built-in interactive 3D graph visualization. Nodes float in 3D space with glowing orbital seeds, particle beam propagation links, 3D camera controls, and real-time score overlays.
- **Graph-Based Reasoning:** Content does not exist in isolation. A viral social media post traces back through news articles to a planted seed. The agent must reason over the *entire network*, node timestamps, source domains, and edge relationships.
- **3 Graded Tasks:** Progresses from content classification (`easy`) to multi-hop propagation graph tracing (`medium`) to numerical harm severity rating (`hard`).
- **Partial Progress Signals at Every Step:** Emits `tag_progress`, `trace_progress`, `score_progress`, and weighted `cumulative` reward signals at *every step*, enabling dense RL/reward feedback.
- **100% Deterministic Oracle Grader:** Zero LLM calls in evaluation. All metrics are calculated via BFS path analysis, exact F1 scores, and RMSE — 100% reproducible and offline-auditable.
- **Interactive Web UI Studio:** Embedded modern glassmorphism web dashboard to inspect nodes, edges, claims, manually perform actions, and watch benchmark metrics update live.
- **Production-Hardened Engine:** Optimized BFS ($O(V+E)$), safe input validations, cached scenario I/O, trace deduplication, and fallback support for environments without Pydantic.

---

## 📋 The 3 Tasks

### 1. Task 1 — Node Classification `(easy)`
- **Objective:** Tag every graph node with the correct label (`real`, `disinformation`, `satire`, `misleading`, `unverified`).
- **Primary Metric:** `tag_f1` (F1 score of `disinformation` node predictions).
- **Reasoning:** Content understanding of article/post text, source domain credibility, share count, and timestamps.

### 2. Task 2 — Propagation Tracing `(medium)`
- **Objective:** Assert upstream source relationships — claim which nodes are origins or spreaders of other nodes (`src → dst`).
- **Primary Metric:** `trace_score` (Mean BFS path-existence score).
  - Valid path existence in ground truth: `1.0`
  - Backwards trace (destination to source): `0.25` partial credit
  - No path / missing node: `0.0`
- **Reasoning:** Multi-hop network reasoning combining timestamps (earlier = source), propagation relations (`shares`, `paraphrases`, `quotes`, `refutes`), and domain trust.

### 3. Task 3 — Claim Severity Rating `(hard)`
- **Objective:** Assign a float severity score `[0.0 – 1.0]` to factual claims based on real-world societal harm potential.
- **Primary Metric:** `severity_score` = `1 − normalised RMSE` vs hidden ground-truth severities.
- **Scoring Guide:**
  - `0.0`: Completely harmless (local news, weather forecasts)
  - `0.3 – 0.5`: Moderately misleading but not physically dangerous
  - `0.7 – 0.9`: Dangerous health misinformation, financial fraud
  - `1.0`: Incitement to violent crime or fatal medical advice

---

## 📐 Scoring Formula

The overall benchmark composite score is calculated as:

$$\text{Final Score} = 0.40 \times \text{Tag F1} + 0.35 \times \text{Trace Score} + 0.25 \times \text{Severity Score}$$

All sub-scores and final scores are strictly bounded in $[0.0, 1.0]$. An ideal oracle agent achieves a score of `1.0000`.

---

## 📁 Project Architecture & File Directory

```
disinfo_final_submission/
├── models.py           # Typed Pydantic & Dataclass models (Observation, Actions, Rewards)
├── disinfo_env.py      # Core DisinfoEnv environment (reset, step, state, evaluate)
├── grader.py           # Deterministic oracle grader (BFS path search, Tag F1, Severity RMSE)
├── graph_factory.py    # Synthetic rumour network generator (seeds, articles, posts, claims)
├── scenarios.json      # Preset graph configurations (easy, default, hard, adversarial)
├── app.py              # FastAPI REST server & Web Studio handler
├── inference.py        # Baseline LLM Agent runner (OpenAI API / Dry-run execution)
├── openenv.yaml        # OpenEnv Standard Specification manifest file
├── Dockerfile          # Hugging Face Spaces & container build file
├── pyproject.toml      # PEP 517 build config & CLI script entrypoint
├── requirements.txt    # Python dependencies
├── static/             # Built-in Web UI Studio
│   ├── index.html      # Glassmorphism HTML dashboard
│   ├── styles.css      # Dark mode design system & gauges
│   └── app.js          # Interactive frontend logic & API client
└── tests/              # Test suite
    ├── test_env.py     # Environment & integration tests
    └── test_grader.py  # Unit tests for BFS, F1, and RMSE functions
```

---

## 🛠️ Summary of Applied Bug Fixes & Code Improvements

1. **`models.py` Serialization Fix:** Fixed dataclass fallback `model_dump()` so class-level defaults (e.g. `type: str = "tag"`) are never lost in lightweight non-pydantic environments. Added strict bounds validation (`ge=0.0, le=1.0`) to claim severity.
2. **`disinfo_env.py` Robustness & Performance:**
   - Pre-cached `scenarios.json` at module init to eliminate repetitive disk I/O on episode reset.
   - Wrapped action parsing in `step()` with try-except blocks to catch malformed dictionaries without crashing the process.
   - Blocked duplicate traces and self-traces (`src == dst`).
   - Safely handled float parsing for claim severities.
3. **`grader.py` Algorithmic Optimization:**
   - Converted BFS queue dequeue from $O(V)$ `list.pop(0)` to $O(1)$ `collections.deque.popleft()`, boosting BFS graph traversal performance.
   - Handled zero-disinformation ground-truth edge case in F1 calculations.
   - Added trace deduplication and prediction clamping to prevent score inflation.
4. **`graph_factory.py` Bound Validation:** Added explicit boundary assertion to prevent crashes when zero seeds or articles are configured.
5. **`app.py` & `pyproject.toml` Packaging:** Fixed route indentation, updated `build-backend` to modern `setuptools.build_meta`, and pointed CLI script `disinfo-analyst` to `inference:main`.

---

## 🚀 How to Run (Step-by-Step Instructions)

### Option 1: Run Interactive Web Studio UI Locally

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Launch the FastAPI server:
   ```bash
   uvicorn app:app --host 0.0.0.0 --port 7860
   ```
3. Open your browser and navigate to:
   ```text
   http://localhost:7860/
   ```
   *You will see the interactive glassmorphism Web Studio where you can visually inspect nodes, assign tags, test propagation links, set claim severities, and observe live reward progress!*

---

### Option 2: Python Code Usage (Direct API)

```python
from disinfo_env import DisinfoEnv

# Initialize environment
env = DisinfoEnv(seed=42)

# Reset for Task 1 (Node Classification)
obs = env.reset(task="task1_classify", scenario="easy")

# Inspect nodes in observation
print(f"Total nodes: {len(obs.nodes)}")
print(f"First node text: {obs.nodes[0].text}")

# Execute action (tag a node)
result = env.step({
    "type": "tag",
    "node_id": obs.nodes[0].node_id,
    "label": "disinformation"
})

print(f"Step Reward: {result.reward.step_reward}")
print(f"Running Tag F1: {result.reward.tag_progress}")

# Evaluate episode
final_eval = env.evaluate()
print(f"Final Composite Score: {final_eval.final_score:.4f}")
```

---

### Option 3: Run Baseline Agent (Dry-Run / No API Key Required)

To verify the complete environment without needing an OpenAI key:
```bash
python inference.py --dry-run --seed 42
```

To run with an LLM (OpenAI / HuggingFace Router):
```bash
export OPENAI_API_KEY=sk-...
python inference.py --task task1_classify --seed 42
```

---

### Option 4: Docker Container Deployment (Hugging Face Spaces)

Build and run the Docker image:
```bash
docker build -t disinfo-analyst .
docker run -p 7860:7860 disinfo-analyst
```
Access the web UI or REST API at `http://localhost:7860`.

---

## 🧪 Running Tests

To run the full unit and integration test suite:
```bash
python -m pytest tests/ -v
```

---

## 📜 License

MIT License. Designed for open research, LLM evaluation, and OpenEnv benchmarks.
